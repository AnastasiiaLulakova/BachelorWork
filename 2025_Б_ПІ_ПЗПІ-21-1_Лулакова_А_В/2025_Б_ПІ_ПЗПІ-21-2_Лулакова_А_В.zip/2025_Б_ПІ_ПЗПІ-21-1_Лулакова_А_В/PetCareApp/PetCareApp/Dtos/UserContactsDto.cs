﻿namespace PetCareApp.Dtos
{
    public class UserContactsDto
    {
        public string Name { get; set; }
        public string Phone { get; set; }
    }
}
