﻿namespace PetCareApp.Dtos
{
    public class CityDto
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string AdminName { get; set; }
        public int CountryId { get; set; }
    }
}
