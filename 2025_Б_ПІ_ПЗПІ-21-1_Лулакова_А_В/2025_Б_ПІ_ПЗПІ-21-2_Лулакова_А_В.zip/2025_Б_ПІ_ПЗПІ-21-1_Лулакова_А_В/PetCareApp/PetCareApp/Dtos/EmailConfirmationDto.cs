﻿namespace PetCareApp.Dtos
{
    public class EmailConfirmationDto
    {
        public string Email { get; set; } = string.Empty;
        public string checkNumber { get; set; } = string.Empty;

        public bool IsPasswordChange { get; set; } = false;
    }
}
