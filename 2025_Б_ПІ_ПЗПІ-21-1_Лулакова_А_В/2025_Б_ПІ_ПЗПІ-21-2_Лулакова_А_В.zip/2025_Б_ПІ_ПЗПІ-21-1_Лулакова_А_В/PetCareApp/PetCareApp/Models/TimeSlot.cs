﻿namespace PetCareApp.Models
{
    public class TimeSlot
    {
        public DateTime Date { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
   
    }
}
