﻿namespace WebPetCare.Resources
{
    public class Organization
    {
    }
}
