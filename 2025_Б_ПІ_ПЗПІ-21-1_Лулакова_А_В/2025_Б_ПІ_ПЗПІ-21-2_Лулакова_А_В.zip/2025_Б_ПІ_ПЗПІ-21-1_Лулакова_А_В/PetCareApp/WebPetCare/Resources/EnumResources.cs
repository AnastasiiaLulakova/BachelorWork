﻿namespace WebPetCare.Resources
{
    public class EnumResources
    {
    }
}
