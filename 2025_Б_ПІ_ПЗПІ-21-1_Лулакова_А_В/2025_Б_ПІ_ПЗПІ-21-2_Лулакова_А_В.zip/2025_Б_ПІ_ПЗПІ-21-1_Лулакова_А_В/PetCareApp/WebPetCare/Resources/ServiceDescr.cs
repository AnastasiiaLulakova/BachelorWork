﻿namespace WebPetCare.Resources
{
    public class ServiceDescr
    {
    }
}
