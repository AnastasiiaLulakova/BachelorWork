﻿namespace WebPetCare.Resources
{
    public class Search
    {
    }
}
