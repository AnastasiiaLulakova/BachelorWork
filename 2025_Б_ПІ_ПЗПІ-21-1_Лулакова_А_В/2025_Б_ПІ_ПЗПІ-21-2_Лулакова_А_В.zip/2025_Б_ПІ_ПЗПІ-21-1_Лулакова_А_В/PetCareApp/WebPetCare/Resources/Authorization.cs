﻿namespace WebPetCare.Resources
{
    public class Authorization
    {
    }
}
