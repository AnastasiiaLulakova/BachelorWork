﻿namespace WebPetCare.Resources
{
    public class Account
    {
    }
}
